import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { Search, MessageSquare, ShieldCheck, User, Settings, Lock } from 'lucide-react-native';
import { View, Text } from 'react-native';
import { useTranslation } from 'react-i18next';

import SearchScreen from '../screens/SearchScreen';
import ChatScreen from '../screens/ChatScreen';
import InsuranceScreen from '../screens/InsuranceScreen';
import SitterProfileScreen from '../screens/SitterProfileScreen';
import BookingScreen from '../screens/BookingScreen';
import VerificationScreen from '../screens/VerificationScreen';
import AdminDashboardScreen from '../screens/AdminDashboardScreen';
import { COLORS } from '../config/theme';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/Button';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

function SearchStack() {
  const { t } = useTranslation();
  return (
    <Stack.Navigator>
      <Stack.Screen name="SearchHome" component={SearchScreen} options={{ title: 'BABS' }} />
      <Stack.Screen name="SitterProfile" component={SitterProfileScreen} options={{ title: t('profile') }} />
      <Stack.Screen name="Booking" component={BookingScreen} options={{ title: 'Booking' }} />
    </Stack.Navigator>
  );
}

function LoginScreen() {
  const { t } = useTranslation();
  // Simplified login for demo
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 }}>
      <Lock size={64} color={COLORS.primary} style={{ marginBottom: 20 }} />
      <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 10 }}>{t('welcome')}</Text>
      <Text style={{ textAlign: 'center', color: COLORS.textSecondary, marginBottom: 30 }}>
        Meld je aan om babysitters in de buurt te vinden.
      </Text>
      <Button title="Login (Demo)" onPress={() => {}} style={{ width: '100%' }} />
    </View>
  );
}

export default function RootNavigator() {
  const { user, loading } = useAuth();
  const { t } = useTranslation();

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>Loading...</Text>
      </View>
    );
  }

  // For the purpose of this demo, we'll show the app even if not logged in, 
  // but the structure is here for real auth.
  const isAuthenticated = true; 

  if (!isAuthenticated) {
    return (
      <Stack.Navigator>
        <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
      </Stack.Navigator>
    );
  }

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          if (route.name === 'Search') return <Search size={size} color={color} />;
          if (route.name === 'Messages') return <MessageSquare size={size} color={color} />;
          if (route.name === 'Insurance') return <ShieldCheck size={size} color={color} />;
          if (route.name === 'Verification') return <ShieldCheck size={size} color={color} />;
          if (route.name === 'Admin') return <Settings size={size} color={color} />;
          return <User size={size} color={color} />;
        },
        tabBarActiveTintColor: COLORS.primary,
        tabBarInactiveTintColor: 'gray',
      })}
    >
      <Tab.Screen name="Search" component={SearchStack} options={{ headerShown: false }} />
      <Tab.Screen name="Messages" component={ChatScreen} options={{ title: t('messages') }} />
      <Tab.Screen name="Insurance" component={InsuranceScreen} options={{ title: t('insurance') }} />
      <Tab.Screen name="Verification" component={VerificationScreen} options={{ title: t('verification') }} />
      <Tab.Screen name="Admin" component={AdminDashboardScreen} options={{ title: t('admin') }} />
    </Tab.Navigator>
  );
}
