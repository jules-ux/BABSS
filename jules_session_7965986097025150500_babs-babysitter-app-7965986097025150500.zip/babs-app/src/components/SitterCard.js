import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { Star, ShieldCheck } from 'lucide-react-native';
import { COLORS, RADIUS, SPACING, SHADOW } from '../config/theme';

export const SitterCard = ({ sitter }) => {
  return (
    <View style={styles.card}>
      <View style={styles.imageContainer}>
        <Image source={{ uri: sitter.imageUrl }} style={styles.image} />
        {sitter.isVerified && (
          <View style={styles.verifiedBadge}>
            <ShieldCheck size={14} color={COLORS.white} />
          </View>
        )}
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{sitter.tag || '2 sittings samen'}</Text>
        </View>
      </View>
      <View style={styles.info}>
        <View style={styles.header}>
          <Text style={styles.name}>{sitter.name}, {sitter.age}</Text>
          <View style={styles.ratingContainer}>
            <Star size={16} color={COLORS.secondary} fill={COLORS.secondary} />
            <Text style={styles.ratingText}>{sitter.rating}</Text>
          </View>
        </View>
        <Text style={styles.location}>{sitter.location}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLORS.white,
    borderRadius: RADIUS.lg,
    overflow: 'hidden',
    marginBottom: SPACING.md,
    ...SHADOW.light,
  },
  imageContainer: {
    height: 200,
    width: '100%',
    position: 'relative',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  badge: {
    position: 'absolute',
    top: SPACING.md,
    left: SPACING.md,
    backgroundColor: COLORS.primary,
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.xs,
    borderRadius: RADIUS.sm,
  },
  badgeText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: 'bold',
  },
  verifiedBadge: {
    position: 'absolute',
    bottom: SPACING.md,
    right: SPACING.md,
    backgroundColor: COLORS.accent,
    padding: 4,
    borderRadius: RADIUS.round,
  },
  info: {
    padding: SPACING.md,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  name: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.text,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    marginLeft: 4,
    fontWeight: 'bold',
    fontSize: 16,
  },
  location: {
    color: COLORS.textSecondary,
    marginTop: 4,
  },
});
