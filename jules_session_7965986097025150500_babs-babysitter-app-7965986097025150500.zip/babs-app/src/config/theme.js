export const COLORS = {
  primary: '#00C896', // The green from the screenshot
  secondary: '#FFD700', // Yellow
  accent: '#FF5A5F', // Red for the phone/emergency
  background: '#FFFFFF',
  text: '#1A1A1A',
  textSecondary: '#666666',
  lightGray: '#F5F5F5',
  border: '#EEEEEE',
  success: '#28A745',
  warning: '#FFC107',
  error: '#DC3545',
  white: '#FFFFFF',
  black: '#000000',
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
};

export const RADIUS = {
  sm: 8,
  md: 12,
  lg: 20,
  round: 999,
};

export const SHADOW = {
  light: {
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
};
