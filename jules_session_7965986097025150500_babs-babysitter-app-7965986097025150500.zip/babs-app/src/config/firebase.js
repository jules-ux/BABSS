import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// These are placeholder values. In a real app, these should be in an .env file.
const firebaseConfig = {
  apiKey: "AIzaSyPlaceholder-Key-For-BABS-App",
  authDomain: "babs-app.firebaseapp.com",
  projectId: "babs-app",
  storageBucket: "babs-app.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdef123456"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export default app;
