import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { Shield, CheckCircle2, Award, MessageCircle } from 'lucide-react-native';
import { useTranslation } from 'react-i18next';
import { COLORS, SPACING, RADIUS } from '../config/theme';
import { Button } from '../components/Button';

export default function SitterProfileScreen({ route, navigation }) {
  const { t } = useTranslation();
  
  const sitter = {
    name: 'Marieke',
    age: 26,
    location: '1050 Elsene',
    rating: 4.9,
    sittings: 42,
    scores: 40,
    about: 'Betrouwbare en zorgzame babysitter met een oprechte liefde voor kinderen en een talent voor het organiseren van leuke en leerzame activiteiten. Meer dan 5 jaar...',
    verifiedStripe: true,
    verifiedItsme: true,
    hasInsurance: true,
    imageUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=400',
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image source={{ uri: sitter.imageUrl }} style={styles.profileImage} />
        <View style={styles.ratingBadge}>
          <Text style={styles.ratingText}>⭐ {sitter.rating}</Text>
          <Text style={styles.statsText}>{sitter.sittings} sittings</Text>
        </View>
      </View>

      <View style={styles.content}>
        <Text style={styles.name}>{sitter.name}, {sitter.age}</Text>
        <Text style={styles.location}>{sitter.location}</Text>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('about')}</Text>
          <Text style={styles.description}>{sitter.about}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('certificates')}</Text>
          <View style={styles.itemRow}>
            <View style={[styles.iconContainer, { backgroundColor: '#E6F9F4' }]}>
              <Award size={20} color={COLORS.primary} />
            </View>
            <View>
              <Text style={styles.itemTitle}>Bsitter</Text>
              <Text style={styles.itemSub}>De beste babysitters op BABS</Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('trust_elements')}</Text>
          
          <View style={styles.itemRow}>
            <Image source={{ uri: 'https://upload.wikimedia.org/wikipedia/commons/e/e0/Itsme_logo.png' }} style={styles.miniLogo} />
            <Text style={styles.itemText}>{t('itsme_verified')}</Text>
            {sitter.verifiedItsme && <CheckCircle2 size={18} color={COLORS.primary} style={styles.check} />}
          </View>

          <View style={styles.itemRow}>
            <Shield size={20} color={COLORS.primary} />
            <Text style={styles.itemText}>{t('stripe_id_check')}</Text>
            {sitter.verifiedStripe && <CheckCircle2 size={18} color={COLORS.primary} style={styles.check} />}
          </View>

          <View style={styles.itemRow}>
            <Shield size={20} color={COLORS.primary} />
            <Text style={styles.itemText}>{t('insured_by')}</Text>
            {sitter.hasInsurance && <CheckCircle2 size={18} color={COLORS.primary} style={styles.check} />}
          </View>
        </View>

        <View style={styles.footer}>
          <Button 
            title={`${t('book_now')} ${sitter.name}`} 
            onPress={() => navigation.navigate('Booking')} 
            style={{ flex: 1 }} 
          />
          <TouchableOpacity 
            style={styles.chatButton} 
            onPress={() => navigation.navigate('Messages')}
          >
            <MessageCircle color={COLORS.primary} />
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  header: {
    height: 300,
    position: 'relative',
  },
  profileImage: {
    width: '100%',
    height: '100%',
  },
  ratingBadge: {
    position: 'absolute',
    bottom: SPACING.md,
    right: SPACING.md,
    backgroundColor: 'rgba(255,255,255,0.9)',
    padding: SPACING.sm,
    borderRadius: RADIUS.md,
    alignItems: 'flex-end',
  },
  ratingText: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  statsText: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  content: {
    padding: SPACING.lg,
    marginTop: -RADIUS.lg,
    backgroundColor: COLORS.white,
    borderTopLeftRadius: RADIUS.lg,
    borderTopRightRadius: RADIUS.lg,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.text,
  },
  location: {
    fontSize: 16,
    color: COLORS.textSecondary,
    marginBottom: SPACING.lg,
  },
  section: {
    marginBottom: SPACING.xl,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: SPACING.md,
  },
  description: {
    fontSize: 16,
    lineHeight: 24,
    color: COLORS.textSecondary,
  },
  itemRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: SPACING.sm,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  iconContainer: {
    padding: SPACING.sm,
    borderRadius: RADIUS.sm,
    marginRight: SPACING.md,
  },
  itemTitle: {
    fontSize: 16,
    fontWeight: '600',
  },
  itemSub: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  itemText: {
    flex: 1,
    fontSize: 16,
    marginLeft: SPACING.md,
  },
  miniLogo: {
    width: 24,
    height: 24,
    borderRadius: 4,
  },
  check: {
    marginLeft: 'auto',
  },
  footer: {
    flexDirection: 'row',
    gap: SPACING.md,
    paddingVertical: SPACING.lg,
  },
  chatButton: {
    width: 56,
    height: 56,
    borderRadius: RADIUS.md,
    borderWidth: 1,
    borderColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
