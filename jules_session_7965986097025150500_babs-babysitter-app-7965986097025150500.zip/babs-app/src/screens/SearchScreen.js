import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TextInput, TouchableOpacity } from 'react-native';
import { Search, Filter, Map as MapIcon, List } from 'lucide-react-native';
import MapView, { Circle } from 'react-native-maps';
import { useTranslation } from 'react-i18next';
import { COLORS, SPACING, RADIUS, SHADOW } from '../config/theme';
import { SitterCard } from '../components/SitterCard';

const MOCK_SITTERS = [
  {
    id: '1',
    name: 'Marieke',
    age: 26,
    location: '1050 Elsene',
    rating: 4.9,
    imageUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=400',
    isVerified: true,
    coordinate: { latitude: 50.825, longitude: 4.365 },
  },
  {
    id: '2',
    name: 'Sarah',
    age: 22,
    location: '1000 Brussel',
    rating: 4.7,
    imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=400',
    isVerified: true,
    coordinate: { latitude: 50.845, longitude: 4.355 },
  },
  {
    id: '3',
    name: 'Emma',
    age: 24,
    location: '1060 Sint-Gillis',
    rating: 4.8,
    imageUrl: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=400',
    isVerified: false,
    coordinate: { latitude: 50.820, longitude: 4.345 },
  },
];

export default function SearchScreen({ navigation }) {
  const { t } = useTranslation();
  const [viewMode, setViewMode] = useState('list');
  const [searchQuery, setSearchQuery] = useState('');

  const renderSitter = ({ item }) => (
    <TouchableOpacity onPress={() => navigation.navigate('SitterProfile', { sitterId: item.id })}>
      <SitterCard sitter={item} />
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.searchHeader}>
        <View style={styles.searchBar}>
          <Search size={20} color={COLORS.textSecondary} />
          <TextInput 
            placeholder={t('search_sitter')} 
            style={styles.searchInput}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          <TouchableOpacity style={styles.filterButton}>
            <Filter size={20} color={COLORS.primary} />
          </TouchableOpacity>
        </View>
        <TouchableOpacity 
          style={styles.toggleViewButton} 
          onPress={() => setViewMode(viewMode === 'list' ? 'map' : 'list')}
        >
          {viewMode === 'list' ? (
            <MapIcon size={24} color={COLORS.white} />
          ) : (
            <List size={24} color={COLORS.white} />
          )}
        </TouchableOpacity>
      </View>

      {viewMode === 'list' ? (
        <FlatList
          data={MOCK_SITTERS}
          renderItem={renderSitter}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <View style={styles.mapContainer}>
          <MapView
            style={styles.map}
            initialRegion={{
              latitude: 50.835,
              longitude: 4.355,
              latitudeDelta: 0.05,
              longitudeDelta: 0.05,
            }}
          >
            {MOCK_SITTERS.map(sitter => (
              <Circle
                key={sitter.id}
                center={sitter.coordinate}
                radius={500}
                strokeColor={COLORS.primary}
                fillColor={COLORS.primary + '40'}
              />
            ))}
          </MapView>
          <View style={styles.mapOverlay}>
            <Text style={styles.mapHint}>{t('approx_location')}</Text>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.lightGray,
  },
  searchHeader: {
    flexDirection: 'row',
    padding: SPACING.md,
    alignItems: 'center',
    backgroundColor: COLORS.white,
    ...SHADOW.light,
    zIndex: 10,
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.lightGray,
    borderRadius: RADIUS.md,
    paddingHorizontal: SPACING.md,
    marginRight: SPACING.sm,
  },
  searchInput: {
    flex: 1,
    paddingVertical: SPACING.sm,
    marginLeft: SPACING.sm,
    fontSize: 16,
  },
  filterButton: {
    padding: SPACING.xs,
  },
  toggleViewButton: {
    backgroundColor: COLORS.primary,
    padding: SPACING.sm,
    borderRadius: RADIUS.md,
    ...SHADOW.light,
  },
  listContent: {
    padding: SPACING.md,
  },
  mapContainer: {
    flex: 1,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  mapOverlay: {
    position: 'absolute',
    bottom: SPACING.lg,
    alignSelf: 'center',
    backgroundColor: 'rgba(0,0,0,0.6)',
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    borderRadius: RADIUS.round,
  },
  mapHint: {
    color: COLORS.white,
    fontSize: 12,
  },
});
