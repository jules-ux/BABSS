import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { Calendar, Clock, CreditCard, Lock } from 'lucide-react-native';
import { useTranslation } from 'react-i18next';
import { COLORS, SPACING, RADIUS, SHADOW } from '../config/theme';
import { Button } from '../components/Button';

export default function BookingScreen({ navigation }) {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);

  const handlePayment = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      Alert.alert(
        "Payment Successful",
        "Your booking for Marieke has been confirmed.",
        [{ text: "OK", onPress: () => navigation.navigate('SearchHome') }]
      );
    }, 2000);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.summaryCard}>
        <Text style={styles.summaryTitle}>Boekingsoverzicht</Text>
        
        <View style={styles.summaryRow}>
          <Calendar size={20} color={COLORS.textSecondary} />
          <Text style={styles.summaryText}>Vrijdag, 25 Okt 2024</Text>
        </View>
        
        <View style={styles.summaryRow}>
          <Clock size={20} color={COLORS.textSecondary} />
          <Text style={styles.summaryText}>18:00 - 22:00 (4 uur)</Text>
        </View>

        <View style={styles.divider} />

        <View style={styles.priceRow}>
          <Text style={styles.priceLabel}>Uurtarief</Text>
          <Text style={styles.priceValue}>€10.00 / uur</Text>
        </View>
        <View style={styles.priceRow}>
          <Text style={styles.priceLabel}>Servicekosten</Text>
          <Text style={styles.priceValue}>€2.50</Text>
        </View>
        <View style={[styles.priceRow, styles.totalRow]}>
          <Text style={styles.totalLabel}>{t('total')}</Text>
          <Text style={styles.totalValue}>€42.50</Text>
        </View>
      </View>

      <View style={styles.paymentSection}>
        <Text style={styles.sectionTitle}>Betaalmethode</Text>
        <TouchableOpacity style={styles.paymentMethod}>
          <CreditCard size={24} color={COLORS.primary} />
          <Text style={styles.paymentMethodText}>Visa **** 4242</Text>
          <Text style={styles.changeText}>Wijzig</Text>
        </TouchableOpacity>

        <View style={styles.secureNote}>
          <Lock size={14} color={COLORS.success} />
          <Text style={styles.secureText}>Beveiligd door Stripe</Text>
        </View>

        <Button 
          title={t('pay_confirm')} 
          onPress={handlePayment} 
          loading={loading}
          style={styles.payButton}
        />
        
        <Text style={styles.disclaimer}>
          Door op 'Nu Betalen' te klikken, ga je akkoord met onze Algemene Voorwaarden en Privacybeleid.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.lightGray,
    padding: SPACING.md,
  },
  summaryCard: {
    backgroundColor: COLORS.white,
    borderRadius: RADIUS.lg,
    padding: SPACING.lg,
    ...SHADOW.light,
    marginBottom: SPACING.lg,
  },
  summaryTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: SPACING.lg,
  },
  summaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  summaryText: {
    marginLeft: SPACING.md,
    fontSize: 16,
    color: COLORS.text,
  },
  divider: {
    height: 1,
    backgroundColor: COLORS.border,
    marginVertical: SPACING.lg,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: SPACING.sm,
  },
  priceLabel: {
    color: COLORS.textSecondary,
    fontSize: 16,
  },
  priceValue: {
    fontSize: 16,
    fontWeight: '500',
  },
  totalRow: {
    marginTop: SPACING.sm,
  },
  totalLabel: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  totalValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  paymentSection: {
    paddingHorizontal: SPACING.sm,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: SPACING.md,
  },
  paymentMethod: {
    backgroundColor: COLORS.white,
    padding: SPACING.md,
    borderRadius: RADIUS.md,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  paymentMethodText: {
    flex: 1,
    marginLeft: SPACING.md,
    fontSize: 16,
    fontWeight: '500',
  },
  changeText: {
    color: COLORS.primary,
    fontWeight: 'bold',
  },
  secureNote: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: SPACING.md,
  },
  secureText: {
    fontSize: 12,
    color: COLORS.success,
    marginLeft: 4,
  },
  payButton: {
    marginTop: SPACING.xl,
  },
  disclaimer: {
    fontSize: 12,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: SPACING.lg,
    lineHeight: 18,
  },
});
