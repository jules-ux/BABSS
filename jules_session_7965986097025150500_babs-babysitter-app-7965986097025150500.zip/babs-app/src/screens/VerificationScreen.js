import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { Shield, Smartphone, FileText, CheckCircle } from 'lucide-react-native';
import { useTranslation } from 'react-i18next';
import { COLORS, SPACING, RADIUS, SHADOW } from '../config/theme';
import { Button } from '../components/Button';

export default function VerificationScreen() {
  const { t } = useTranslation();
  const [stripeStatus, setStripeStatus] = useState('none');
  const [itsmeStatus, setItsmeStatus] = useState('none');

  const handleStripeVerify = () => {
    setStripeStatus('pending');
    setTimeout(() => {
      setStripeStatus('verified');
      Alert.alert('Success', 'Your ID has been successfully verified via Stripe.');
    }, 2000);
  };

  const handleItsmeVerify = () => {
    setItsmeStatus('pending');
    setTimeout(() => {
      setItsmeStatus('verified');
      Alert.alert('Success', 'Your identity has been confirmed via itsme®.');
    }, 2000);
  };

  const VerificationCard = ({ title, description, icon: Icon, status, onPress, color }) => (
    <View style={styles.card}>
      <View style={[styles.iconBox, { backgroundColor: color + '20' }]}>
        <Icon size={32} color={color} />
      </View>
      <View style={styles.cardContent}>
        <Text style={styles.cardTitle}>{title}</Text>
        <Text style={styles.cardDescription}>{description}</Text>
        <Button 
          title={status === 'verified' ? t('verified') : (status === 'pending' ? t('loading') : t('verify_now'))} 
          variant={status === 'verified' ? 'success' : 'primary'}
          onPress={onPress}
          disabled={status !== 'none'}
          loading={status === 'pending'}
          style={styles.cardButton}
        />
      </View>
      {status === 'verified' && (
        <CheckCircle size={24} color={COLORS.success} style={styles.statusIcon} />
      )}
    </View>
  );

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>{t('verification')}</Text>
        <Text style={styles.subtitle}>Verhoog het vertrouwen en vind sneller een match door je identiteit te verifiëren.</Text>
      </View>

      <VerificationCard 
        title={t('stripe_id_title')}
        description={t('stripe_id_desc')}
        icon={Shield}
        status={stripeStatus}
        onPress={handleStripeVerify}
        color={COLORS.primary}
      />

      <VerificationCard 
        title={t('itsme_title')}
        description={t('itsme_desc')}
        icon={Smartphone}
        status={itsmeStatus}
        onPress={handleItsmeVerify}
        color="#FF5A00"
      />

      <View style={styles.infoBox}>
        <FileText size={20} color={COLORS.textSecondary} />
        <Text style={styles.infoText}>
          Je gegevens worden veilig versleuteld en nooit gedeeld met anderen zonder jouw toestemming.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.lightGray,
    padding: SPACING.lg,
  },
  header: {
    marginBottom: SPACING.xl,
    marginTop: SPACING.xl,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.text,
  },
  subtitle: {
    fontSize: 16,
    color: COLORS.textSecondary,
    marginTop: SPACING.sm,
  },
  card: {
    backgroundColor: COLORS.white,
    borderRadius: RADIUS.lg,
    padding: SPACING.lg,
    flexDirection: 'row',
    marginBottom: SPACING.lg,
    ...SHADOW.light,
    position: 'relative',
  },
  iconBox: {
    width: 60,
    height: 60,
    borderRadius: RADIUS.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: SPACING.md,
  },
  cardContent: {
    flex: 1,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.text,
  },
  cardDescription: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginVertical: SPACING.sm,
  },
  cardButton: {
    alignSelf: 'flex-start',
    paddingVertical: SPACING.sm,
    marginTop: SPACING.sm,
  },
  statusIcon: {
    position: 'absolute',
    top: SPACING.md,
    right: SPACING.md,
  },
  infoBox: {
    flexDirection: 'row',
    padding: SPACING.md,
    backgroundColor: COLORS.border,
    borderRadius: RADIUS.md,
    alignItems: 'center',
    marginTop: SPACING.md,
  },
  infoText: {
    flex: 1,
    fontSize: 13,
    color: COLORS.textSecondary,
    marginLeft: SPACING.sm,
  },
});
