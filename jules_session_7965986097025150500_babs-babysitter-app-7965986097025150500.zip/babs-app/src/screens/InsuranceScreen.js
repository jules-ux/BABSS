import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, Alert } from 'react-native';
import { HeartPulse, Home, Baby, ShieldCheck, Info } from 'lucide-react-native';
import { useTranslation } from 'react-i18next';
import { COLORS, SPACING, RADIUS } from '../config/theme';
import { Button } from '../components/Button';

export default function InsuranceScreen() {
  const { t } = useTranslation();
  const [homeInsurance, setHomeInsurance] = useState(false);
  const [kidsInsurance, setKidsInsurance] = useState(false);
  const [isApplying, setIsApplying] = useState(false);

  const handleApply = () => {
    if (!homeInsurance && !kidsInsurance) {
      Alert.alert('Selection required', 'Please select at least one insurance option.');
      return;
    }
    setIsApplying(true);
    setTimeout(() => {
      setIsApplying(false);
      Alert.alert('Application Sent', 'Your insurance application is being processed. We will contact you within 24 hours.');
    }, 1500);
  };

  const InsuranceOption = ({ title, description, icon: Icon, value, onValueChange }) => (
    <View style={styles.optionCard}>
      <View style={styles.optionHeader}>
        <View style={styles.iconContainer}>
          <Icon size={24} color={COLORS.primary} />
        </View>
        <View style={styles.optionTitleContainer}>
          <Text style={styles.optionTitle}>{title}</Text>
        </View>
        <Switch 
          value={value} 
          onValueChange={onValueChange}
          trackColor={{ false: COLORS.border, true: COLORS.primary + '80' }}
          thumbColor={value ? COLORS.primary : '#f4f3f4'}
        />
      </View>
      <Text style={styles.optionDescription}>{description}</Text>
    </View>
  );

  return (
    <ScrollView style={styles.container}>
      <View style={styles.hero}>
        <HeartPulse size={48} color={COLORS.white} />
        <Text style={styles.heroTitle}>{t('insurance_title')}</Text>
        <Text style={styles.heroSubtitle}>{t('insurance_subtitle')}</Text>
      </View>

      <View style={styles.content}>
        <View style={styles.infoBanner}>
          <ShieldCheck size={20} color={COLORS.success} />
          <Text style={styles.infoBannerText}>{t('insured_by')}</Text>
        </View>

        <Text style={styles.sectionTitle}>{t('extra_protection') || 'Extra Bescherming'}</Text>
        
        <InsuranceOption 
          title={t('home_care_plus')}
          description={t('home_care_desc')}
          icon={Home}
          value={homeInsurance}
          onValueChange={setHomeInsurance}
        />

        <InsuranceOption 
          title={t('kids_safe')}
          description={t('kids_safe_desc')}
          icon={Baby}
          value={kidsInsurance}
          onValueChange={setKidsInsurance}
        />

        <View style={styles.pricingBox}>
          <Text style={styles.pricingTitle}>{t('total_overview')}</Text>
          <View style={styles.priceRow}>
            <Text>{t('basic_coverage')}</Text>
            <Text style={styles.freeText}>{t('free')}</Text>
          </View>
          {homeInsurance && (
            <View style={styles.priceRow}>
              <Text>{t('home_care_plus')}</Text>
              <Text>€2.50 / maand</Text>
            </View>
          )}
          {kidsInsurance && (
            <View style={styles.priceRow}>
              <Text>{t('kids_safe')}</Text>
              <Text>€1.99 / maand</Text>
            </View>
          )}
        </View>

        <Button 
          title={t('confirm_application')} 
          onPress={handleApply} 
          loading={isApplying}
          style={styles.applyButton}
        />

        <View style={styles.footerInfo}>
          <Info size={16} color={COLORS.textSecondary} />
          <Text style={styles.footerText}>
            De verzekering wordt geleverd door onze partner AXA. Voorwaarden zijn van toepassing.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  hero: {
    backgroundColor: COLORS.primary,
    padding: SPACING.xl,
    alignItems: 'center',
    paddingBottom: SPACING.xl * 2,
  },
  heroTitle: {
    color: COLORS.white,
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: SPACING.md,
  },
  heroSubtitle: {
    color: COLORS.white,
    opacity: 0.9,
    fontSize: 16,
    marginTop: SPACING.xs,
  },
  content: {
    marginTop: -SPACING.xl,
    backgroundColor: COLORS.white,
    borderTopLeftRadius: RADIUS.lg,
    borderTopRightRadius: RADIUS.lg,
    padding: SPACING.lg,
  },
  infoBanner: {
    flexDirection: 'row',
    backgroundColor: '#E6F9F4',
    padding: SPACING.md,
    borderRadius: RADIUS.md,
    alignItems: 'center',
    marginBottom: SPACING.lg,
  },
  infoBannerText: {
    flex: 1,
    marginLeft: SPACING.sm,
    color: COLORS.text,
    fontSize: 14,
    fontWeight: '500',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: SPACING.md,
    color: COLORS.text,
  },
  optionCard: {
    backgroundColor: COLORS.white,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    marginBottom: SPACING.md,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  optionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: SPACING.sm,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: RADIUS.sm,
    backgroundColor: COLORS.lightGray,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: SPACING.md,
  },
  optionTitleContainer: {
    flex: 1,
  },
  optionTitle: {
    fontSize: 16,
    fontWeight: '700',
  },
  optionDescription: {
    fontSize: 14,
    color: COLORS.textSecondary,
    lineHeight: 20,
  },
  pricingBox: {
    backgroundColor: COLORS.lightGray,
    padding: SPACING.md,
    borderRadius: RADIUS.md,
    marginTop: SPACING.lg,
  },
  pricingTitle: {
    fontWeight: 'bold',
    marginBottom: SPACING.sm,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: SPACING.xs,
  },
  freeText: {
    color: COLORS.success,
    fontWeight: 'bold',
  },
  applyButton: {
    marginTop: SPACING.xl,
  },
  footerInfo: {
    flexDirection: 'row',
    marginTop: SPACING.xl,
    paddingBottom: SPACING.xl,
    alignItems: 'center',
  },
  footerText: {
    flex: 1,
    fontSize: 12,
    color: COLORS.textSecondary,
    marginLeft: SPACING.sm,
  },
});
