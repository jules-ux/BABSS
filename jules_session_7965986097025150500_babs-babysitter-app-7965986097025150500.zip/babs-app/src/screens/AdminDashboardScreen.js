import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Users, CreditCard, ShieldAlert, Settings, ChevronRight, Activity } from 'lucide-react-native';
import { useTranslation } from 'react-i18next';
import { COLORS, SPACING, RADIUS, SHADOW } from '../config/theme';

export default function AdminDashboardScreen() {
  const { t } = useTranslation();

  const StatCard = ({ title, value, icon: Icon, color }) => (
    <View style={styles.statCard}>
      <View style={[styles.statIcon, { backgroundColor: color + '20' }]}>
        <Icon size={24} color={color} />
      </View>
      <View>
        <Text style={styles.statValue}>{value}</Text>
        <Text style={styles.statTitle}>{title}</Text>
      </View>
    </View>
  );

  const ActionRow = ({ title, subtitle, icon: Icon, onPress }) => (
    <TouchableOpacity style={styles.actionRow} onPress={onPress}>
      <View style={styles.actionIcon}>
        <Icon size={20} color={COLORS.text} />
      </View>
      <View style={styles.actionContent}>
        <Text style={styles.actionTitle}>{title}</Text>
        <Text style={styles.actionSubtitle}>{subtitle}</Text>
      </View>
      <ChevronRight size={20} color={COLORS.border} />
    </TouchableOpacity>
  );

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{t('admin')}</Text>
        <Text style={styles.headerSubtitle}>Beheer van het BABS platform</Text>
      </View>

      <View style={styles.statsGrid}>
        <StatCard title={t('stats_users')} value="1,284" icon={Users} color="#4A90E2" />
        <StatCard title={t('stats_revenue')} value="€12,450" icon={CreditCard} color={COLORS.success} />
        <StatCard title={t('stats_open_checks')} value="14" icon={ShieldAlert} color={COLORS.accent} />
        <StatCard title={t('stats_sittings')} value="856" icon={Activity} color={COLORS.secondary} />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Snelkoppelingen</Text>
        
        <ActionRow 
          title={t('manual_assignment')} 
          subtitle="Wijs een Sitter handmatig toe aan een ouder"
          icon={Users}
          onPress={() => {}}
        />
        <ActionRow 
          title={t('review_payments')} 
          subtitle="Controleer verdachte transacties"
          icon={CreditCard}
          onPress={() => {}}
        />
        <ActionRow 
          title={t('verification_queue')} 
          subtitle="14 identiteitsbewijzen wachten op goedkeuring"
          icon={ShieldAlert}
          onPress={() => {}}
        />
        <ActionRow 
          title={t('system_settings')} 
          subtitle="Beheer commissies en tarieven"
          icon={Settings}
          onPress={() => {}}
        />
      </View>

      <View style={styles.recentActivity}>
        <Text style={styles.sectionTitle}>{t('recent_activity')}</Text>
        {[1, 2, 3].map((i) => (
          <View key={i} style={styles.activityItem}>
            <View style={styles.activityDot} />
            <Text style={styles.activityText}>
              <Text style={{ fontWeight: 'bold' }}>Thomas V.</Text> heeft een boeking voltooid met <Text style={{ fontWeight: 'bold' }}>Marieke</Text>.
            </Text>
            <Text style={styles.activityTime}>2m geleden</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.lightGray,
  },
  header: {
    backgroundColor: COLORS.white,
    padding: SPACING.lg,
    paddingTop: SPACING.xl,
    ...SHADOW.light,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.text,
  },
  headerSubtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginTop: 4,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: SPACING.md,
    justifyContent: 'space-between',
  },
  statCard: {
    backgroundColor: COLORS.white,
    width: '48%',
    padding: SPACING.md,
    borderRadius: RADIUS.md,
    marginBottom: SPACING.md,
    flexDirection: 'row',
    alignItems: 'center',
    ...SHADOW.light,
  },
  statIcon: {
    padding: SPACING.sm,
    borderRadius: RADIUS.sm,
    marginRight: SPACING.sm,
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  statTitle: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  section: {
    paddingHorizontal: SPACING.md,
    marginTop: SPACING.md,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: SPACING.md,
    marginLeft: SPACING.xs,
  },
  actionRow: {
    backgroundColor: COLORS.white,
    padding: SPACING.md,
    borderRadius: RADIUS.md,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: SPACING.sm,
    ...SHADOW.light,
  },
  actionIcon: {
    marginRight: SPACING.md,
  },
  actionContent: {
    flex: 1,
  },
  actionTitle: {
    fontSize: 16,
    fontWeight: '600',
  },
  actionSubtitle: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  recentActivity: {
    padding: SPACING.md,
    marginTop: SPACING.md,
    paddingBottom: SPACING.xl,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: SPACING.sm,
  },
  activityDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: COLORS.primary,
    marginRight: SPACING.md,
  },
  activityText: {
    flex: 1,
    fontSize: 14,
  },
  activityTime: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
});
