import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: {
    translation: {
      "welcome": "Welcome to BABS",
      "search_sitter": "Find a Sitter...",
      "book_now": "Book Now",
      "insurance": "Insurance",
      "messages": "Messages",
      "profile": "Profile",
      "verification": "Verification",
      "admin": "Admin",
      "pay_confirm": "Pay & Confirm",
      "total": "Total",
      "about": "About",
      "certificates": "Certificates",
      "trust_elements": "Trust Elements",
      "itsme_verified": "Itsme® verified",
      "stripe_id_check": "ID checked by Stripe",
      "insured_by": "Insured by BABS",
      "approx_location": "Locations are approximate for privacy",
      "insurance_title": "BABS Insurances",
      "insurance_subtitle": "Peace of mind for you and your family.",
      "home_care_plus": "Home Care Plus",
      "home_care_desc": "Coverage for damage to your home or belongings during a babysitting session.",
      "kids_safe": "Kids Safe",
      "kids_safe_desc": "Additional accident insurance specifically for your children during care.",
      "total_overview": "Total Overview",
      "basic_coverage": "Basic Coverage (Standard)",
      "free": "FREE",
      "confirm_application": "Confirm Application",
      "stripe_id_title": "Stripe ID Check",
      "stripe_id_desc": "Secure verification of your ID card or passport.",
      "itsme_title": "itsme® Verification",
      "itsme_desc": "Confirm your identity in seconds with the itsme® app.",
      "verify_now": "Verify Now",
      "verified": "Verified",
      "loading": "Loading...",
      "sittings_together": "sittings together",
      "manual_assignment": "Manual Assignment",
      "review_payments": "Review Payments",
      "verification_queue": "Verification Queue",
      "system_settings": "System Settings",
      "recent_activity": "Recent Activity",
      "stats_users": "Users",
      "stats_revenue": "Revenue",
      "stats_open_checks": "Open ID Checks",
      "stats_sittings": "Sittings",
    }
  },
  nl: {
    translation: {
      "welcome": "Welkom bij BABS",
      "search_sitter": "Zoek een Sitter...",
      "book_now": "Nu Boeken",
      "insurance": "Verzekering",
      "messages": "Berichten",
      "profile": "Profiel",
      "verification": "Verificatie",
      "admin": "Admin",
      "pay_confirm": "Nu Betalen & Bevestigen",
      "total": "Totaal",
      "about": "Over",
      "certificates": "Certificaten",
      "trust_elements": "Elementen van Vertrouwen",
      "itsme_verified": "Itsme® geverifieerd",
      "stripe_id_check": "ID gecontroleerd door Stripe",
      "insured_by": "Verzekerd door BABS",
      "approx_location": "Locaties zijn bij benadering voor privacy",
      "insurance_title": "BABS Verzekeringen",
      "insurance_subtitle": "Gemoedsrust voor jou en je gezin.",
      "home_care_plus": "Home Care Plus",
      "home_care_desc": "Dekking voor schade aan je woning of inboedel tijdens een babysit sessie.",
      "kids_safe": "Kids Safe",
      "kids_safe_desc": "Aanvullende ongevallenverzekering specifiek voor je kinderen tijdens de opvang.",
      "total_overview": "Totaaloverzicht",
      "basic_coverage": "Basisdekking (Standaard)",
      "free": "GRATIS",
      "confirm_application": "Aanvraag Bevestigen",
      "stripe_id_title": "Stripe ID Controle",
      "stripe_id_desc": "Veilige verificatie van je identiteitskaart of paspoort.",
      "itsme_title": "itsme® Verificatie",
      "itsme_desc": "Bevestig je identiteit in enkele seconden met de itsme® app.",
      "verify_now": "Nu Verifiëren",
      "verified": "Geverifieerd",
      "loading": "Laden...",
      "sittings_together": "sittings samen",
      "manual_assignment": "Handmatige Toewijzing",
      "review_payments": "Betalingen Reviewen",
      "verification_queue": "Verificatie Wachtrij",
      "system_settings": "Systeem Instellingen",
      "recent_activity": "Recente Activiteit",
      "stats_users": "Gebruikers",
      "stats_revenue": "Omzet",
      "stats_open_checks": "Open ID Checks",
      "stats_sittings": "Sittings",
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'nl',
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
