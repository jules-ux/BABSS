import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { StripeProvider } from '@stripe/stripe-react-native';
import { AuthProvider } from './src/context/AuthContext';
import RootNavigator from './src/navigation/RootNavigator';
import './src/translations/i18n';

export default function App() {
  return (
    <AuthProvider>
      <StripeProvider
        publishableKey="pk_test_placeholder"
        merchantIdentifier="merchant.com.babs"
      >
        <NavigationContainer>
          <RootNavigator />
        </NavigationContainer>
      </StripeProvider>
    </AuthProvider>
  );
}
